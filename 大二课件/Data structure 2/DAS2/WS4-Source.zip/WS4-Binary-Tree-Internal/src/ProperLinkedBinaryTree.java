import dsa.iface.INode;
import dsa.impl.AbstractBinaryTree;

public class ProperLinkedBinaryTree<T> extends AbstractBinaryTree<T> {

	/**
	 * Constructor - create an empty tree
	 */
	public ProperLinkedBinaryTree() {
		// Part 1
	}

	/**
	 * Expand an external node - Store a value in the external node - Create two
	 * external nodes as children, making {@code n} an internal node
	 * 
	 * @param n
	 *            The node to expand. An exception will be thrown if it is not
	 *            external.
	 * @param e
	 *            The element to be stored in node {@code n}.
	 */
	public void expandExternal(INode<T> n, T e) {
		// Part 2
	}

	/**
	 * Remove a node from the tree
	 * 
	 * @param n
	 *            The node to be removed. An exception will be thrown if it cannot
	 *            be removed (i.e. if it has two internal children).
	 * @return The element that was stored in the removed node.
	 */
	public T remove(INode<T> n) {
		// Part 3
		
		return null; // <-- this is just so the class compiles: remove it from your code
	}
}

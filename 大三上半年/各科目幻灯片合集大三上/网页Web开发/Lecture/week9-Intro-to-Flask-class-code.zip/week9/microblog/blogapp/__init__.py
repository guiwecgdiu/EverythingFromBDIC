from flask import Flask

app = Flask(__name__)

from blogapp import routes